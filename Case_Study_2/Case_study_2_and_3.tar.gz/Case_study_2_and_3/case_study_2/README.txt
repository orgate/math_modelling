down.py - Implementing downwind scheme on continuous flow
downd.py - Implementing downwind scheme on dis-continuous flow
up.py - Implementing upwind scheme on continuous flow
upd.py - Implementing upwind scheme on dis-continuous flow
exp.py - Implementing explicit scheme on continuous flow
expd.py - Implementing explicit scheme on dis-continuous flow
imp.py - Implementing impicit scheme on continuous flow
impd.py - Implementing implicit scheme on dis-continuous flow
lax.py - Implementing Lax-Friedrich scheme on continuous flow
laxd.py - Implementing Lax-Friedrich scheme on dis-continuous flow
lwrlax.py - Implementing LWR model for single lane - simulation using Lax Friedrich scheme
lwrlaxj.py - Implementing LWR model for single lane with traffic jam - simulation using Lax-Friedrich scheme
lwrup.py - Implementing LWR model for single lane - simulation using Upwind scheme
