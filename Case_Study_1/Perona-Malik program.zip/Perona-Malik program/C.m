function c=C(s)
k=0.01;
c=1./(1+(s)/k^2);